const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://toni798:oYBS3R31IjDBeV6i@assignment6.egeygpp.mongodb.net/')

let Schema = mongoose.Schema;

let personSchema = new Schema({
    _id: Number,
    firstName: String, 
    lastName: String,
});

let Person = mongoose.model('Person', personSchema);

let companySchema = new Schema({
    companyName: String,
});

let Company = mongoose.model('Company', companySchema);

let person = new Person({
    _id: 1,
    firstName: 'John',
    lastName: 'Doe',
});

person.save()
.then(()=> {
    console.log('Person saved.');
})
.catch((err) => {
    console.error('Error saving person:', err);
});

let company = new Company({
    companyName: 'ABC Inc.',
});

company.save()
.then(()=> {
    console.log('Company saved.');
})
.catch((err) => {
    console.error('Error saving company:', err);
});