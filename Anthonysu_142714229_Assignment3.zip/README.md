# Lego Collection Website

## Responsive web design 
  * Phone
  * Table
  * Desktop

## FramWork
* Tailwind CSS - use for style and responsive design

## UI
* Daisyui - use for creating the cards, nav, etc

## Host with Render
* Link to website: 